License
=======

.. literalinclude:: ../../LICENSE.txt
