__title__ = "textacy"
__version__ = "0.7.0"
__description__ = "NLP, before and after spaCy"
__url__ = "https://github.com/chartbeat-labs/textacy"
__download_url__ = "https://pypi.org/project/textacy"

__maintainer__ = "Burton DeWilde"
__maintainer_email__ = "burtdewilde@gmail.com"

__license__ = "Apache"
