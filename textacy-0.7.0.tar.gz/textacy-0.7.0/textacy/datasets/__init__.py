from .capitol_words import CapitolWords
from .imdb import IMDB
from .oxford_text_archive import OxfordTextArchive
from .reddit_comments import RedditComments
from .supreme_court import SupremeCourt
from .wikimedia import Wikipedia, Wikinews
